import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ScopeLedger · Good work deserves a clear price",
  description: "Persistent agency change quotes, clear margins, and traceable client review.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
